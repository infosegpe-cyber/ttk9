# 🚀 TikTok Account Creator - Multi-Browser & Stealth
# 📌 Using Invertexto, Firefox Stealth & Ghost Browser Support
# 🖥 Version: 1.3.2

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
import warnings
import time
import random
import string
import sys
import os
import email_invertexto

# Importar gerenciador de drivers para evitar erros de versão
try:
    from webdriver_manager.chrome import ChromeDriverManager
except ImportError:
    print("Instalando dependências necessárias...")
    os.system("pip install webdriver-manager")
    from webdriver_manager.chrome import ChromeDriverManager

# Desativar avisos
warnings.filterwarnings("ignore", category=DeprecationWarning) 

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def load_config():
    config = {}
    try:
        with open("config.txt", "r") as f:
            for line in f:
                if "=" in line and not line.startswith("#"):
                    key, value = line.split("=", 1)
                    config[key.strip()] = value.strip()
    except:
        pass
    return config

def handle_banners(driver, wait):
    """Detecta e fecha banners de cookies e avisos do TikTok usando XPaths específicos."""
    print("Verificando banners e avisos...")
    
    banners = [
        {"selector": '//div/div[2]/button[2]', "name": "Cookies (XPath Direto)", "type": "xpath"},
        {"selector": '/html/body/div[1]/div/div[2]/div[1]/div[2]/div/div/div/div[2]/div/button/div/div', "name": "Aviso Entendi (XPath Direto)", "type": "xpath"},
        {"selector": 'button[data-e2e="cookie-banner-accept"]', "name": "Cookies (Fallback CSS)"},
        {"selector": '//button[contains(text(), "Permitir todos")]', "name": "Cookies (Fallback Texto)", "type": "xpath"},
        {"selector": '//button[contains(text(), "Entendi")]', "name": "Aviso Entendi (Fallback Texto)", "type": "xpath"}
    ]
    
    for banner in banners:
        try:
            if banner.get("type") == "xpath":
                elements = driver.find_elements(By.XPATH, banner["selector"])
            else:
                elements = driver.find_elements(By.CSS_SELECTOR, banner["selector"])
            
            if elements:
                for el in elements:
                    if el.is_displayed():
                        try:
                            el.click()
                        except:
                            driver.execute_script("arguments[0].click();", el)
                        print(f"✅ Fechado: {banner['name']}")
                        time.sleep(1)
                        break
        except:
            pass

def apply_stealth(driver):
    """Aplica scripts de JavaScript para ocultar marcas de automação."""
    stealth_script = """
    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
    Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
    Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
    const getParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(parameter) {
      if (parameter === 37445) return 'Intel Inc.';
      if (parameter === 37446) return 'Intel(R) Iris(TM) Plus Graphics 640';
      return getParameter.apply(this, arguments);
    };
    """
    driver.execute_script(stealth_script)

def main():
    clear()
    print ("""\
     _____ _ _  _____     _              
    |_   _(_) ||_   _|   | |             
      | |  _| | _| | ___ | | __          
      | | | | |/ / |/ _ \| |/ /          
      | | | |   <| | (_) |   <           
      \_/ |_|_|\_\_/\___/|_|\_\                                                                               
    """)
    
    print("1. Firefox (Stealth Mode)")
    print("2. Ghost Browser (Chromium Based)")
    choice = input("\nSelecione o navegador (1 ou 2): ")
    
    config = load_config()
    driver = None
    url = 'https://www.tiktok.com/signup/phone-or-email/email'
    
    try:
        if choice == "2":
            print("Iniciando Ghost Browser...")
            ghost_path = config.get("GHOST_BROWSER_PATH", "")
            if not ghost_path or not os.path.exists(ghost_path):
                print(f"Erro: Caminho do Ghost Browser não encontrado: {ghost_path}")
                print("Verifique o arquivo config.txt")
                return
            
            chrome_options = ChromeOptions()
            chrome_options.binary_location = ghost_path
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # Usar o ChromeDriverManager para baixar o driver compatível com a versão do Ghost Browser
            service = ChromeService(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
        else:
            print("Iniciando Firefox Stealth...")
            options = webdriver.FirefoxOptions()
            options.set_preference("dom.webdriver.enabled", False)
            options.set_preference("useAutomationExtension", False)
            try:
                driver = webdriver.Firefox(options=options)
            except:
                driver = webdriver.Firefox(executable_path="./geckodriver.exe", options=options)

        apply_stealth(driver)
        wait = WebDriverWait(driver, 25)
        driver.get(url)
        
        time.sleep(4)
        handle_banners(driver, wait)
        
        print("Configurando idioma...")
        try:
            lang_select_el = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="app"]/div/div[3]/div[2]/div[1]/select')))
            lang_select = Select(lang_select_el)
            lang_select.select_by_value('en')
            time.sleep(2)
            handle_banners(driver, wait)
        except: pass

        print("Configurando data de nascimento...")
        birthday_selectors = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-e2e="select-container"]')))
        
        birthday_selectors[0].click()
        time.sleep(1)
        month_options = wait.until(EC.presence_of_all_elements_located((By.XPATH, '//div[contains(@id, "Month-options")]//div[@role="option"]')))
        random.choice(month_options).click()
        
        time.sleep(0.5)
        birthday_selectors[1].click()
        time.sleep(1)
        day_options = wait.until(EC.presence_of_all_elements_located((By.XPATH, '//div[contains(@id, "Day-options")]//div[@role="option"]')))
        random.choice(day_options[:28]).click()
        
        time.sleep(0.5)
        birthday_selectors[2].click()
        time.sleep(1)
        year_options = wait.until(EC.presence_of_all_elements_located((By.XPATH, '//div[contains(@id, "Year-options")]//div[@role="option"]')))
        year_options[random.randint(20, 30)].click()
        
        generated_email, generated_password = email_invertexto.novo_email()
        if not generated_email: return
        
        print(f"E-mail: {generated_email}")
        email_field = wait.until(EC.presence_of_element_located((By.NAME, "email")))
        for char in generated_email:
            email_field.send_keys(char)
            time.sleep(random.uniform(0.05, 0.1))
            
        password_field = driver.find_element(By.CSS_SELECTOR, 'input[type="password"]')
        for char in generated_password:
            password_field.send_keys(char)
            time.sleep(random.uniform(0.05, 0.1))

        time.sleep(1)
        wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-e2e="send-code-button"]'))).click()

        print("Aguardando código...")
        get_code = None
        start_time = time.time()
        while (time.time() - start_time < 180):
            msgs = email_invertexto.ler_caixa(generated_email)
            get_code = email_invertexto.extrair_codigo_tiktok(msgs)
            if get_code: break
            time.sleep(6)
        
        if get_code:
            print(f"✅ Código: {get_code}")
            code_field = driver.find_element(By.CSS_SELECTOR, 'input[placeholder*="digit"], input[placeholder*="código"]')
            for char in get_code:
                code_field.send_keys(char)
                time.sleep(0.1)
            time.sleep(1)
            driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]').click()
            print("\nConta criada! Verifique o navegador.")
        else:
            print("\n❌ Código não recebido.")

    except Exception as e:
        print(f"Erro: {e}")
    finally:
        if driver: print("\nNavegador aberto para inspeção.")

if __name__ == "__main__":
    main()
