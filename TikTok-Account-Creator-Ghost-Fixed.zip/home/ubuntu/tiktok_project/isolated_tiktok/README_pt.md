<div align="center">
  <h3>Proxy-Pool-API | Usado por este Repositório</h3>
  <br>
  <a href="https://proxy-pool-api.onrender.com" target="_blank">
    <img src="proxy.gif" alt="texto alternativo" width="2000px">
  </a>
  <p>Acesse uma API de pool de proxies 100% gratuita! Integre proxies de forma rápida e fácil em seus projetos.</p>
  <br>
  <p> Visite <a href="https://proxy-pool-api.onrender.com" target="_blank">proxy-pool-api.onrender.com</a> para começar.</p>
</div>


# Criador de Contas TikTok

🚀 Crie quantidades infinitas de Contas TikTok. 🚀

🏗 Gerencie suas Contas TikTok. 🏗

📌 Ver. 0.0.1 📌

## Funcionalidades

- Senha de entrada aleatória
- Salvar detalhes da Conta após a Criação em arquivo .csv
- Criação de Conta Totalmente Automática 🤖

## Começando

Esse script pode criar Contas TikTok.
Essas instruções farão com que você tenha uma cópia do projeto funcionando em sua máquina local para fins de desenvolvimento e teste.

### Suporte 👨‍💻

Qualquer problema ao executar o script e quaisquer dúvidas, entre em contato comigo via Twitter [@hendrik_bgr](https://twitter.com/Hendrik_bgr)

### Pré-requisitos

Baixe a versão mais recente do 'chromedriver' e coloque-a na pasta 'driver' dentro da pasta do projeto. (Nota: O código atual parece usar `geckodriver` para Firefox, verifique o `run.py`)

Você precisa do python 3 instalado no seu Sistema.

Obtenha uma cópia do Projeto. Abra seu Terminal e digite:

```
git clone https://github.com/hendrikbgr/TikTok-Account-Creator
```

Para instalar todos os requisitos necessários, execute o seguinte comando no diretório do projeto:

```
pip install -r requirements.txt
```

Depois disso, você pode prosseguir para editar o Script.

## Executando 🏃🏽‍♂️

Para executar este script, abra seu Terminal no diretório do projeto.

Para iniciar o Script de Criação de Email, digite:

```
python run.py
```

## Autores

- **Hendrik Bgr** - _Trabalho inicial_ - [HendrikBgr](https://github.com/hendrikbgr)

## Agradecimentos

- Dica para qualquer pessoa cujo código foi usado

## Lista de Tarefas 📝

- Adicionar suporte a proxy
- Modo Totalmente Automático
- Verificação Automática
- Adicionar modo de lista de email

## Bugs Conhecidos 🐛

- O processo de verificação ainda precisa ser feito manualmente. ⚠️
