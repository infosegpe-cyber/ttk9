import requests
import json
import time
import re
import string
import random

def get_headers():
    """Retorna headers realistas para simular um navegador."""
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        "Origin": "https://www.invertexto.com",
        "Referer": "https://www.invertexto.com/gerador-email-temporario",
        "Connection": "keep-alive"
    }

def novo_email():
    """
    Gera um novo e-mail temporário. 
    Tenta usar o endpoint AJAX, se falhar, gera um e-mail aleatório seguindo o padrão do site.
    """
    url = "https://www.invertexto.com/gerador-email-temporario/ajax"
    payload = {"action": "generate"}
    
    try:
        session = requests.Session()
        # Tenta pegar o e-mail via AJAX
        r = session.post(url, data=payload, headers=get_headers(), timeout=10)
        
        if r.status_code == 200:
            try:
                data = r.json()
                email = data.get("email")
                if email:
                    # Gerar senha para o TikTok
                    chars = string.ascii_letters + string.digits + "!@#$%&*"
                    password = "".join(random.choice(chars) for _ in range(12))
                    return email, password
            except:
                pass
        
        # Fallback: Se o AJAX falhar (bloqueio), o site usa domínios como @uorak.com
        # Vamos gerar um nome aleatório e usar o domínio padrão
        user = "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(8))
        email = f"{user}@uorak.com"
        chars = string.ascii_letters + string.digits + "!@#$%&*"
        password = "".join(random.choice(chars) for _ in range(12))
        print(f"Aviso: Usando e-mail gerado manualmente: {email}")
        return email, password
        
    except Exception as e:
        print(f"Erro ao gerar e-mail: {e}")
        return None, None

def ler_caixa(email):
    """
    Consulta as mensagens recebidas no e-mail fornecido.
    """
    url = "https://www.invertexto.com/gerador-email-temporario/ajax"
    params = {"action": "check", "email": email}
    
    try:
        r = requests.get(url, params=params, headers=get_headers(), timeout=10)
        if r.status_code == 200:
            try:
                return r.json()
            except:
                return []
        return []
    except Exception as e:
        # print(f"Erro ao ler caixa: {e}")
        return []

def extrair_codigo_tiktok(mensagens):
    """
    Analisa as mensagens em busca do código de verificação do TikTok.
    """
    if not mensagens or not isinstance(mensagens, list):
        return None
        
    for msg in mensagens:
        subject = str(msg.get("subject", ""))
        body = str(msg.get("body", ""))
        
        # Procurar por 6 dígitos numéricos
        match = re.search(r'(\d{6})', subject)
        if not match:
            match = re.search(r'(\d{6})', body)
            
        if match:
            return match.group(1)
    return None
